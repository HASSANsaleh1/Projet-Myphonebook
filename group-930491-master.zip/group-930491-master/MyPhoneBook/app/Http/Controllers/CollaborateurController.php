<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Collaborateur;
use App\Models\Entreprise;

class CollaborateurController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $collaborateurs=Collaborateur::orderBy("nom","asc")->paginate(10);
        return view('collaborateurs/index',compact("collaborateurs"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $entreprises=Entreprise::all();
        return view('collaborateurs/create',compact('entreprises'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        $request->validate([
            'civilite'=>'required',
            'nom' => 'required',
            'prenom'=> 'required',
            'rue' => 'required',
            'cp' => 'required',
            'ville' => 'required',
            'tel' => 'required',
            'email' => 'required',
            'entreprise_id' =>'required',
        ]);

        Collaborateur::create([
            'civilite'=>$request->civilite,
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'rue' => $request->rue,
            'cp' => $request->cp,
            'ville' => $request->ville,
            'tel'=>$request->tel,
            'email' => $request->email,
            'entreprise_id' =>$request->entreprise_id
        ]);

        return redirect()->route('collaborateurs.index')
                        ->with('success','Collaborateur ajouté avec succès.');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Collaborateur $collaborateurs)
    {
        $entreprises=Entreprise::all();
        return view('collaborateurs/show',compact('collaborateurs','entreprises'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Collaborateur $collaborateurs)
    {
        $entreprises=Entreprise::all();
        return view('collaborateurs/edit',compact('collaborateurs','entreprises'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, Collaborateur $collaborateurs)
    {

        $request->validate([
            'civilite'=>'required:civilite',
            'nom' => 'required:nom',
            'prenom'=> 'required:prenom',
            'rue' => 'required:rue',
            'cp' => 'required:cp',
            'ville' => 'required:ville',
            'tel' => 'required:tel',
            'email' => 'required:email',
            'entreprise_id' =>'required:entreprise_id',
        ]);

        $collaborateurs->update([
            'civilite'=>$request->civilite,
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'rue' => $request->rue,
            'cp' => $request->cp,
            'ville' => $request->ville,
            'tel'=>$request->tel,
            'email' => $request->email,
            'entreprise_id' =>$request->entreprise_id
        ]);

        return redirect()->route('collaborateurs.index')->with('success','Vos modifications ont été sauvegardées.');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Collaborateur $collaborateurs)
    {
        $collaborateurs->delete();

        return redirect()->route('collaborateurs.index')
                        ->with('success','Collaborateur supprimé.');
    }
}

