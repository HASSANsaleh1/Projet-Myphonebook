<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Entreprise;

class EntrepriseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $entreprises=Entreprise::orderBy("nom","asc")->paginate(10);
        return view('entreprises/index',compact("entreprises"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('entreprises/create');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required',
            'rue' => 'required',
            'cp' => 'required',
            'ville' => 'required',
            'tel'=>'required',
            'email' => 'required',
        ]);

        Entreprise::create([
            'nom' => $request->nom,
            'rue' => $request->rue,
            'cp' => $request->cp,
            'ville' => $request->ville,
            'tel'=>$request->tel,
            'email' => $request->email,
        ]);

        return redirect()->route('entreprises.index')
                        ->with('success','Entreprise ajouté avec succès.');
    }


   /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Entreprise $entreprises)
    {
        return view('entreprises/show',compact('entreprises'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Entreprise $entreprises)
    {
        return view('entreprises/edit',compact('entreprises'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, Entreprise $entreprises)
    {
        $request->validate([
            'nom' => 'required',
            'rue' => 'required',
            'cp' => 'required',
            'ville' => 'required',
            'email' => 'required',
        ]);

        $entreprises->update([
            'nom' => $request->nom,
            'rue' => $request->rue,
            'cp' => $request->cp,
            'ville' => $request->ville,
            'tel'=>$request->tel,
            'email' => $request->email,
        ]);
        return redirect()->route('entreprises.index')
                        ->with('success','Vos modifications ont été sauvegardées.');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Entreprise $entreprises)
    {
        $entreprises->delete();

        return redirect()->route('entreprises.index')
                        ->with('success','Entreprise supprimé.');
    }
}

