<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/', [App\Http\Controllers\AccueilController::class, 'index'])->name('Accueil');

Auth::routes();



/*
|----------------------------------------------------------
| Web Routes
|----------------------------------------------------------
*/



Route::group(['prefix' => 'entreprises'], function() {
    Route::get('/index',[App\Http\Controllers\EntrepriseController::class, 'index'])->middleware('role:Admin,Gestionnaire,User')->name('entreprises.index');
    Route::get('/create',[App\Http\Controllers\EntrepriseController::class, 'create'])->middleware('role:Admin,Gestionnaire,null')->name('entreprises.create');
    Route::post('/create',[App\Http\Controllers\EntrepriseController::class, 'store'])->middleware('role:Admin,Gestionnaire,null')->name('entreprises.store');
    Route::put('{entreprises}/update',[App\Http\Controllers\EntrepriseController::class, 'update'])->middleware('role:Admin,Gestionnaire,null')->name('entreprises.update');
    Route::get('{entreprises}/edit',[App\Http\Controllers\EntrepriseController::class, 'edit'])->middleware('role:Admin,Gestionnaire,null')->name('entreprises.edit');
    Route::get('{entreprises}/show',[App\Http\Controllers\EntrepriseController::class, 'show'])->middleware('role:Admin,Gestionnaire,User')->name('entreprises.show');
    Route::delete('{entreprises}/destroy',[App\Http\Controllers\EntrepriseController::class, 'destroy'])->middleware('role:Admin,null,null')->name('entreprises.destroy');
});
    Route::group(['prefix' => 'collaborateurs'], function() {
        Route::get('/index',[App\Http\Controllers\CollaborateurController::class, 'index'])->middleware('role:Admin,Gestionnaire,User')->name('collaborateurs.index');
        Route::get('/create',[App\Http\Controllers\CollaborateurController::class, 'create'])->middleware('role:Admin,Gestionnaire,null')->name('collaborateurs.create');
        Route::post('/create',[App\Http\Controllers\CollaborateurController::class, 'store'])->middleware('role:Admin,Gestionnaire,null')->name('collaborateurs.store');
        Route::put('{collaborateurs}/update',[App\Http\Controllers\CollaborateurController::class, 'update'])->middleware('role:Admin,Gestionnaire,null')->name('collaborateurs.update');
        Route::get('{collaborateurs}/edit',[App\Http\Controllers\CollaborateurController::class, 'edit'])->middleware('role:Admin,Gestionnaire,null')->name('collaborateurs.edit');
        Route::get('{collaborateurs}/show',[App\Http\Controllers\CollaborateurController::class, 'show'])->middleware('role:Admin,Gestionnaire,User')->name('collaborateurs.show');
        Route::delete('{collaborateurs}/destroy',[App\Http\Controllers\CollaborateurController::class, 'destroy'])->middleware('role:Admin,null,null')->name('collaborateurs.destroy');
    });

Route::get('/login',[App\Http\Controllers\Auth\AuthenticatedSessionController::class,'create'])->name('login');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Auth::routes();
