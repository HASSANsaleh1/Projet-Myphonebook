@extends('layouts.app')

@section('content')
<div class="container">
    <form  method="POST" action="{{ route("entreprises.update", ['entreprises' => $entreprises->id ]) }}">
        @csrf
        <input type="hidden" name="_method" value="put">
      <fieldset>
        <legend>Ajouter un Entreprise</legend>

        <div class="form-group">
          <label for="nom">Nom</label>
          <input type="text" class="form-control" name="nom" value="{{ $entreprises->nom }}">
        </div>

          <div class="form-group">
            <label for="rue">Rue</label>
            <input type="text" class="form-control" name="rue" value="{{ $entreprises->rue }}">
          </div>

          <div class="form-group">
            <label for="cp">Code postale</label>
            <input type="text" class="form-control" name="cp" pattern="[0-9]{5}" value="{{ $entreprises->cp }}">
          </div>

          <div class="form-group">
            <label for="ville">Ville</label>
            <input type="text" class="form-control" name="ville" value="{{ $entreprises->ville }}">
          </div>

          <div class="form-group">
            <label for="tel">Numéro de téléphone</label>
            <input type="text" class="form-control" name="tel" value="{{ $entreprises->tel }}">
          </div>
        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" class="form-control" name="email" value="{{ $entreprises->email }}">
        </div>

        <div class="pull-right">
            <button type="submit" class="btn btn-success"> Sauvegarder</a>
            </div>
      </fieldset>

    </form>
</div>
@endsection
