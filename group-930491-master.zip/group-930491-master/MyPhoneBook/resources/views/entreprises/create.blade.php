@extends('layouts.app')

@section('content')
<div class="container">
    <form method="post" action="{{ route("entreprises.store") }}" >
        @csrf
      <fieldset>
        <legend>Ajouter un Entreprise</legend>

        <div class="form-group">
          <label for="nom">Nom</label>
          <input type="text" class="form-control" name="nom" placeholder="Entrez le nom ici" required>
        </div>

          <div class="form-group">
            <label for="nom">Rue</label>
            <input type="text" class="form-control" name="rue" placeholder="Entrez la riue ici" required>
          </div>

          <div class="form-group">
            <label for="nom">Code postale</label>
            <input type="text" class="form-control" name="cp" pattern="[0-9]{5}" placeholder="Entrez votre code postale ici" required>
          </div>

          <div class="form-group">
            <label for="nom">Ville</label>
            <input type="text" class="form-control" name="ville" placeholder="Entrez votre ville ici" required>
          </div>

          <div class="form-group">
            <label for="nom">Numéro de téléphone</label>
            <input type="text" class="form-control" name="tel" placeholder="Ex: 0607500890" required>
          </div>
        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" class="form-control" name="email" placeholder="Ex: pierre.giraud@edhec.com" required>
        </div>


        <div class="pull-right">
            <button type="submit" class="btn btn-success"> Ajouter mon entreprise</a>
        </div>
      </fieldset>
    </form>
</div>
@endsection
