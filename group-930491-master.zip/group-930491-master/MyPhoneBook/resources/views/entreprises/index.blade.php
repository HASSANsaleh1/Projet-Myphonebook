@extends('layouts.app')

@section('content')
    <div class="row" style="margin: 60px">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left" style="font-size: 40px">
                <h2 >Liste des Entreprises</h2>
            </div>
        </br>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('entreprises.create') }}"> Créer une nouvelle Entreprise</a>
            </div>
        </div>
    </div>



    <table class="table table-bordered" style="margin: 60px">
    <thead>
        <tr>
            <th>id</th>
            <th>Nom</th>
            <th>Tel</th>
            <th>E-mail</th>
            <th>Code Postale</th>
            <th> Actions </th>
        </tr>
    </thead>
    <tbody>
        @foreach ($entreprises as $e)
        <tr>
        <th scope="row">{{ $e->id }}</th>
        <td>{{ $e->nom }}</td>
        <td>{{ $e->tel }}</td>
        <td>{{ $e->email }}</td>
        <td>{{ $e->cp }}</td>
        <td>
        <a href="{{ route('entreprises.edit',['entreprises' => $e]) }}" class="btn btn-info">Edit</a>
        <a href="{{ route('entreprises.show',['entreprises'=> $e]) }}" class="btn btn-success" >Show</a>
        <a href="#" class="btn btn-danger"
        onclick="if(confirm('Voulez-vous vraiment supprimer cet entreprise?')){ document.getElementById('form-{{ $e->id }}').submit()}">Delete</a>

        <form id="form-{{ $e->id }}"
        action="{{ route('entreprises.destroy', ['entreprises' => $e->id]) }}"
        method="post">
        @csrf
        <input type="hidden" name="_method" value="delete">
        </form>
        </td>
        </tr>
        @endforeach
        </tbody>
    </table>

@endsection
