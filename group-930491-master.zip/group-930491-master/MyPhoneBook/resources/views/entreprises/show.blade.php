@extends('layouts.app')

@section('content')
<div class="container">
    <form  method="POST" action="{{ route("entreprises.update", ['entreprises' => $entreprises->id ]) }}">
        @csrf
        <input type="hidden" name="_method" value="put">
      <fieldset>
        <legend>Données personnels de {{ $entreprises->nom }} :</legend>

        <div class="form-group">
          <label for="nom">Nom</label>
          <input type="text" class="form-control" name="nom" value="{{ $entreprises->nom }}" disabled>
        </div>

          <div class="form-group">
            <label for="rue">Rue</label>
            <input type="text" class="form-control" name="rue" value="{{ $entreprises->rue }}" disabled>
          </div>

          <div class="form-group">
            <label for="cp">Code postale</label>
            <input type="text" class="form-control" name="cp" value="{{ $entreprises->cp }}" disabled>
          </div>

          <div class="form-group">
            <label for="ville">Ville</label>
            <input type="text" class="form-control" name="ville" value="{{ $entreprises->ville }}" disabled>
          </div>

          <div class="form-group">
            <label for="tel">Numéro de téléphone</label>
            <input type="text" class="form-control" name="tel" value="{{ $entreprises->tel }}" disabled>
          </div>
        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" class="form-control" name="email" value="{{ $entreprises->email }}" disabled>
        </div>

      </fieldset>

    </form>
</div>
@endsection
