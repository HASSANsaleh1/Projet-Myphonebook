@extends('layouts.app')

@section('content')
<div class="container">
    <form  method="post" action="{{ route("collaborateurs.update", ['collaborateurs' => $collaborateurs->id ]) }}">
        @csrf
        <input type="hidden" name="_method" value="put">
      <fieldset>
        <legend>Modifier les données du Collaborateur</legend>

        <div class="form-group">
            <label for="selection">Sélectionnez la civilité du collaborateur</label>
            <select name="civilite" aria-label="civilite"class="form-control">
              <option >{{ $collaborateurs->civilite }}</option>
                <option  value="Homme">Homme</option>
                <option  value="Femme">Femme</option>
                <option  value="Non-binaire">Non-binaire</option>
            </select>
          </div>

          <div class="form-group">
            <label for="nom">Nom</label>
            <input type="text" class="form-control" name="nom" value="{{ $collaborateurs->nom }}">
          </div>

        <div class="form-group">
            <label for="nom">Prénom</label>
            <input type="text" class="form-control" name="prenom" value="{{ $collaborateurs->prenom }}">
          </div>

          <div class="form-group">
            <label for="rue">Rue</label>
            <input type="text" class="form-control" name="rue" value="{{ $collaborateurs->rue }}">
          </div>

          <div class="form-group">
            <label for="cp">Code postale</label>
            <input type="text" class="form-control" name="cp" pattern="[0-9]{5}" value="{{ $collaborateurs->cp }}">
          </div>

          <div class="form-group">
            <label for="ville">Ville</label>
            <input type="text" class="form-control" name="ville" value="{{ $collaborateurs->ville }}">
          </div>

          <div class="form-group">
            <label for="tel">Numéro de téléphone</label>
            <input type="tel" class="form-control" name="tel" value="{{ $collaborateurs->tel }}">
          </div>

        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" class="form-control" name="email" value="{{ $collaborateurs->email }}">
        </div>

        <div class="form-group">
            <label for="selection">L'entreprise du collaborateur</label>
            <select name="entreprise_id" class="form-control">
              <option value ="{{  $collaborateurs->entreprise_id}}">{{ $collaborateurs->entreprise->nom }}</option>

                  @foreach ($entreprises as $e)
                <option  value="{{ $e->id }}" >{{ $e->nom }}</option>
                @endforeach

            </select>
          </div>
        <div class="pull-right">
            <button type="submit" class="btn btn-success"> Sauvegarder</a>
            </div>
      </fieldset>
    </form>
</div>
@endsection
