@extends('layouts.app')

@section('content')
    <div class="row" style="margin: 60px">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right" style="font-size: 40px">
                <h2 >Liste des Collaborateurs</h2>
            </div>
        </br>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('collaborateurs.create') }}"> Créer un nouveau Collaborateur</a>
            </div>
        </div>
    </div>



    <table class="table table-bordered" style="margin: 60px">
    <thead>
        <tr>
            <th>id</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Tel</th>
            <th>E-mail</th>
            <th> Numéro de l'entreprise</th>
            <th> Nom de l'entreprise</th>
            <th> Actions </th>
        </tr>
    </thead>
    <tbody>
        @foreach ($collaborateurs as $c )

        <th scope="row">{{ $c->id }}</th>
        <td>{{ $c->nom }}</td>
        <td>{{ $c->prenom }}</td>
        <td>{{ $c->tel }}</td>
        <td>{{ $c->email }}</td>
        <td>{{ $c->entreprise->tel }}</td>
        <td>{{ $c->entreprise->nom }}</td>

        <td>
            <a href="{{ route('collaborateurs.edit',['collaborateurs'=> $c]) }}" class="btn btn-info">Edit</a>
            <a href="{{ route('collaborateurs.show',['collaborateurs'=> $c]) }}" class="btn btn-success">Show</a>
            <a href="#" class="btn btn-danger"
        onclick="if(confirm('Voulez-vous vraiment supprimer ce collaborateur?')){ document.getElementById('form-{{ $c->id }}').submit()}">Delete</a>

        <form id="form-{{ $c->id }}"
        action="{{ route('collaborateurs.destroy', ['collaborateurs' => $c->id]) }}"
        method="post">
        @csrf
        <input type="hidden" name="_method" value="delete">
        </form>
            </td>
        </tr>

        @endforeach
        </tbody>
    </table>

@endsection
