@extends('layouts.app')

@section('content')
<div class="container">
    <form  method="POST" action="{{ route("collaborateurs.update", ['collaborateurs' => $collaborateurs->id ]) }}">
        @csrf
        <input type="hidden" name="_method" value="put">
      <fieldset>
        <legend>Données personnels de {{ $collaborateurs->nom }} {{ $collaborateurs->prenom }} :</legend>

          <div class="form-group">
            <label for="nom">Civilité</label>
            <input type="text" class="form-control" name="civilite" value="{{ $collaborateurs->civilite }}"  disabled>
          </div>

          <div class="form-group">
            <label for="nom">Nom</label>
            <input type="text" class="form-control" name="nom" value="{{ $collaborateurs->nom }}"  disabled>
          </div>

        <div class="form-group">
            <label for="nom">Prénom</label>
            <input type="text" class="form-control" name="prenom"  value="{{ $collaborateurs->prenom }}" disabled>
          </div>

          <div class="form-group">
            <label for="rue">Rue</label>
            <input type="text" class="form-control" name="rue" value="{{ $collaborateurs->rue }}" disabled>
          </div>

          <div class="form-group">
            <label for="cp">Code postale</label>
            <input type="text" class="form-control" name="cp" value="{{ $collaborateurs->cp }}" disabled>
          </div>

          <div class="form-group">
            <label for="ville">Ville</label>
            <input type="text" class="form-control" name="ville" value="{{ $collaborateurs->ville }}" disabled>
          </div>

          <div class="form-group">
            <label for="tel">Numéro de téléphone</label>
            <input type="text" class="form-control" name="tel" value="{{ $collaborateurs->tel }}" disabled>
          </div>

        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" class="form-control" name="email" value="{{ $collaborateurs->email }}" disabled>
        </div>

        <div class="form-group">
            <label for="entreprise">Nom de l'entreprise</label>
            <input type="nom" class="form-control" name="nom" value="{{ $collaborateurs->entreprise->nom }}" disabled>
          </div>

      </fieldset>
    </form>
</div>
@endsection
