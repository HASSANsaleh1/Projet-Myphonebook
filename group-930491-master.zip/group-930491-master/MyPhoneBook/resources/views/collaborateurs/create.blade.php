@extends('layouts.app')

@section('content')
<div class="container">
    <form method="post" action="{{ route("collaborateurs.store") }}" >
        @csrf
      <fieldset>
        <legend>Ajouter un Collaborateur</legend>

        <div class="form-group">
            <label for="selection">Sélectionnez la civilité du collaborateur</label>
            <select name="civilite" aria-label="civilite"class="form-control">
              <option selected>Liste des civilités...</option>
                <option  value="Homme">Homme</option>
                <option  value="Femme">Femme</option>
                <option  value="Non-binaire">Non-binaire</option>
            </select>
          </div>

        <div class="form-group">
            <label for="nom">Nom</label>
            <input type="text" class="form-control" name="nom" placeholder="Entrez le nom ici" required>
          </div>

          <div class="form-group">
              <label for="prenom">Prénom</label>
              <input type="text" class="form-control" name="prenom" placeholder="Entrez le prénom ici" required>
            </div>

            <div class="form-group">
              <label for="rue">Rue</label>
              <input type="text" class="form-control" name="rue" placeholder="Entrez la riue ici" required>
            </div>

            <div class="form-group">
              <label for="cp">Code postale</label>
              <input type="text" class="form-control" name="cp" pattern="[0-9]{5}" placeholder="Entrez votre code postale ici" required>
            </div>

            <div class="form-group">
              <label for="ville">Ville</label>
              <input type="text" class="form-control" name="ville" placeholder="Entrez votre ville ici" required>
            </div>

            <div class="form-group">
              <label for="tel">Numéro de téléphone</label>
              <input type="text" class="form-control" name="tel" placeholder="Ex: 0607500890">
            </div>
          <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" class="form-control" name="email" placeholder="Ex: pierre.giraud@edhec.com" required>
          </div>

       <div class="form-group">
          <label for="selection">Sélectionnez l'entreprise du collaborateur</label>
          <select name="entreprise_id" class="form-control">
            <option selected>Liste des entreprises...</option>

                @foreach ($entreprises as $e)
              <option value="{{ $e->id }}" >{{ $e->nom }}</option>
              @endforeach

          </select>
        </div>
        <div class="pull-right">
            <button type="submit" class="btn btn-success"> Ajouter mon collaborateur</a>
        </div>
      </fieldset>
    </form>
</div>
@endsection
