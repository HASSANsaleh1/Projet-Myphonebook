<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CollaborateursSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('collaborateurs')->insert([
            'civilite' => 'Homme',
            'nom' => 'NomCollaborateur1',
            'prenom' => 'Prenom',
            'rue' => 'Rue',
            'cp' => '12300',
            'ville' => 'ville',
            'tel' => '0612345678',
            'email' => 'collaborateur1@gmail.com',
            'entreprise_id' => '1'
        ]);
        DB::table('collaborateurs')->insert([
            'civilite' => 'Homme',
            'nom' => 'NomCollaborateur2',
            'prenom' => 'Prenom2',
            'rue' => 'Rue',
            'cp' => '15480',
            'ville' => 'ville',
            'tel' => '0645876215',
            'email' => 'collaborateur2@gmail.com',
            'entreprise_id' => '2'
        ]);
        DB::table('collaborateurs')->insert([
            'civilite' => 'Femme',
            'nom' => 'NomCollaborateur3',
            'prenom' => 'Prenom3',
            'rue' => 'Rue',
            'cp' => '69058',
            'ville' => 'ville',
            'tel' => '0645876217',
            'email' => 'collaborateur3@gmail.com',
            'entreprise_id' => '3'
        ]);
        DB::table('collaborateurs')->insert([
            'civilite' => 'Non-binaire',
            'nom' => 'NomCollaborateur4',
            'prenom' => 'Prenom4',
            'rue' => 'Rue',
            'cp' => '48705',
            'ville' => 'ville',
            'tel' => '0645876219',
            'email' => 'collaborateur4@gmail.com',
            'entreprise_id' => '4'
        ]);
        DB::table('collaborateurs')->insert([
            'civilite' => 'Homme',
            'nom' => 'NomCollaborateur5',
            'prenom' => 'Prenom5',
            'rue' => 'Rue',
            'cp' => '52018',
            'ville' => 'ville',
            'tel' => '0645876218',
            'email' => 'collaborateur5@gmail.com',
            'entreprise_id' => '5'
        ]);
        DB::table('collaborateurs')->insert([
            'civilite' => 'Femme',
            'nom' => 'NomCollaborateur6',
            'prenom' => 'Prenom6',
            'rue' => 'Rue',
            'cp' => '51802',
            'ville' => 'ville',
            'tel' => '0645876210',
            'email' => 'collaborateur6@gmail.com',
            'entreprise_id' => '6'
        ]);

    }
}
