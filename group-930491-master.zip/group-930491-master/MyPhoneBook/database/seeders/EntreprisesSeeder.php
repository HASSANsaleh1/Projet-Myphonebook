<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EntreprisesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('entreprises')->insert([
            'id' =>'1',
            'nom' => 'NomEntreprise1',
            'rue' => 'Rue',
            'cp' => '12300',
            'ville' => 'ville',
            'tel' => '0612345678',
            'email' => 'entreprise1@gmail.com'
        ]);
        DB::table('entreprises')->insert([
            'id' =>'2',
            'nom' => 'NomEntreprise2',
            'rue' => 'Rue',
            'cp' => '15048',
            'ville' => 'ville',
            'tel' => '0645876215',
            'email' => 'entreprise2@gmail.com'
        ]);
        DB::table('entreprises')->insert([
            'id' =>'3',
            'nom' => 'NomEntreprise3',
            'rue' => 'Rue',
            'cp' => '69508',
            'ville' => 'ville',
            'tel' => '0645876217',
            'email' => 'entreprise3@gmail.com'
        ]);
        DB::table('entreprises')->insert([
            'id' =>'4',
            'nom' => 'NomEntreprise4',
            'rue' => 'Rue',
            'cp' => '48705',
            'ville' => 'ville',
            'tel' => '0645876219',
            'email' => 'entreprise4@gmail.com'
        ]);
        DB::table('entreprises')->insert([
            'id' =>'5',
            'nom' => 'NomEntreprise5',
            'rue' => 'Rue',
            'cp' => '52108',
            'ville' => 'ville',
            'tel' => '0645876218',
            'email' => 'entreprise5@gmail.com'
        ]);
        DB::table('entreprises')->insert([
            'id' =>'6',
            'nom' => 'NomEntreprise6',
            'rue' => 'Rue',
            'cp' => '51082',
            'ville' => 'ville',
            'tel' => '0645876210',
            'email' => 'entreprise6@gmail.com'
        ]);


    }
}
