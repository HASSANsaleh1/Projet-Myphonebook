<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'admin',
            'email' => 'admin@etna.fr',
            'password' => bcrypt('admin'),
            'role' => 'admin'
        ]);

        DB::table('users')->insert([
            'name' => 'gestionnaire',
            'email' => 'gest@etna.fr',
            'password' => bcrypt('gestionnaire'),
            'role' => 'gestionnaire'
        ]);

        DB::table('users')->insert([
            'name' => 'user',
            'email' => 'user@etna.fr',
            'password' => bcrypt('user'),
            'role' => 'user'
        ]);
    }
}
