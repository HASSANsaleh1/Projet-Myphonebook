<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCollaborateursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('collaborateurs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->enum('civilite',array('Homme','Femme','Non-binaire'));
            $table->string('nom')->unique();
            $table->string('prenom')->unique();
            $table->string('rue');
            $table->string('cp',5);
            $table->string('ville');
            $table->string('tel')->unique();
            $table->string('email');
            $table->foreignId('entreprise_id')->constrained("entreprises");
            $table->rememberToken();
            $table->timestamps();

            Schema::enableForeignKeyConstraints();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table("collaborateurs", function (Blueprint $table) {
            $table->dropForeign("entreprise_id");
            });
        Schema::dropIfExists('collaborateurs');
    }
}
